
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `action_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_id` int(10) unsigned NOT NULL,
  `target_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` int(10) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` int(10) unsigned DEFAULT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `exception` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `action_events_actionable_type_actionable_id_index` (`actionable_type`,`actionable_id`),
  KEY `action_events_batch_id_model_type_model_id_index` (`batch_id`,`model_type`,`model_id`),
  KEY `action_events_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `action_events` WRITE;
/*!40000 ALTER TABLE `action_events` DISABLE KEYS */;
INSERT INTO `action_events` VALUES (1,'8c79a09f-e30a-4fe5-9d3e-cb9b06a1d23b',1,'Update','App\\Models\\User',1,'App\\Models\\User',1,'App\\Models\\User',1,'','finished','','2018-12-11 15:55:37','2018-12-11 15:55:37'),(2,'8c79adda-c76b-44ec-8e6e-200998bb2011',1,'Update','App\\Models\\Event',1,'App\\Models\\Event',1,'App\\Models\\Event',1,'','finished','','2018-12-11 16:32:37','2018-12-11 16:32:37'),(3,'8c79ae18-743d-4952-ade6-4fdbcde2bb5c',1,'Update','App\\Models\\Event',1,'App\\Models\\Event',1,'App\\Models\\Event',1,'','finished','','2018-12-11 16:33:17','2018-12-11 16:33:17'),(4,'8c79ae3d-a4f3-4e27-9487-360f97ff8fc0',1,'Update','App\\Models\\Event',1,'App\\Models\\Event',1,'App\\Models\\Event',1,'','finished','','2018-12-11 16:33:42','2018-12-11 16:33:42'),(5,'8c853479-0e98-4b98-a81f-9a0564e12078',1,'Update','App\\Models\\User',3,'App\\Models\\User',3,'App\\Models\\User',3,'','finished','','2018-12-17 10:03:08','2018-12-17 10:03:08'),(6,'8c853920-89a1-44f2-8c06-2cc4d0eba27b',3,'Update','App\\Models\\User',3,'App\\Models\\User',3,'App\\Models\\User',3,'','finished','','2018-12-17 10:16:09','2018-12-17 10:16:09'),(7,'8c893891-154d-459c-9b18-831d4b0914e5',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 09:57:54','2018-12-19 09:57:54'),(8,'8c8938f3-6ee1-484e-87b9-45a259e01b1a',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 09:58:58','2018-12-19 09:58:58'),(9,'8c893906-3cdf-4892-8839-b8526097fab1',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 09:59:11','2018-12-19 09:59:11'),(10,'8c893948-7a5a-4155-8728-fb3b2a204c6f',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 09:59:54','2018-12-19 09:59:54'),(11,'8c893959-0f9b-4c93-9ed7-739acd63c2cc',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 10:00:05','2018-12-19 10:00:05'),(12,'8c893980-4821-4958-a9b8-38c21e73e78a',1,'Delete','App\\Models\\Event',1,'App\\Models\\Event',1,'App\\Models\\Event',1,'','finished','','2018-12-19 10:00:31','2018-12-19 10:00:31'),(13,'8c893a02-6130-4d13-a99b-9701aaba8ec7',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 10:01:56','2018-12-19 10:01:56'),(14,'8c893a2f-ebbd-4a35-a68e-693c3de0901d',1,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 10:02:26','2018-12-19 10:02:26'),(15,'8c8987c2-58bf-46f9-bace-712a0718a093',2,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 13:39:20','2018-12-19 13:39:20'),(16,'8c8987ef-ad86-4e81-a555-ca9478f027ca',2,'Update','App\\Models\\Event',2,'App\\Models\\Event',2,'App\\Models\\Event',2,'','finished','','2018-12-19 13:39:50','2018-12-19 13:39:50'),(17,'8c89883e-14f5-44f4-a211-b785a4151717',2,'Update','App\\Models\\User',2,'App\\Models\\User',2,'App\\Models\\User',2,'','finished','','2018-12-19 13:40:41','2018-12-19 13:40:41'),(18,'8c8b6dff-3455-426c-9bb9-4166df76f365',2,'Update','App\\Models\\Event',4,'App\\Models\\Event',4,'App\\Models\\Event',4,'','finished','','2018-12-20 12:18:57','2018-12-20 12:18:57'),(19,'8c8b78fd-ab71-4d59-90f4-90cbe62b2c03',1,'Update','App\\Models\\Event',4,'App\\Models\\Event',4,'App\\Models\\Event',4,'','finished','','2018-12-20 12:49:42','2018-12-20 12:49:42'),(20,'8c8b8c4c-9dcd-4ecd-b4f1-f9d9e4db09c5',2,'Update','App\\Models\\Event',4,'App\\Models\\Event',4,'App\\Models\\Event',4,'','finished','','2018-12-20 13:43:41','2018-12-20 13:43:41');
/*!40000 ALTER TABLE `action_events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meetup_id` int(11) NOT NULL,
  `meetup_com_event_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `venue_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `intro` longtext COLLATE utf8mb4_unicode_ci,
  `sponsors` longtext COLLATE utf8mb4_unicode_ci,
  `schedule` longtext COLLATE utf8mb4_unicode_ci,
  `speaker_1_abstract` longtext COLLATE utf8mb4_unicode_ci,
  `speaker_2_abstract` longtext COLLATE utf8mb4_unicode_ci,
  `tweet` longtext COLLATE utf8mb4_unicode_ci,
  `tweet_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (2,1,'vtkdppyzcbfc','Digipolis','2018-12-19 12:39:50','<div>For our first meetup of 2019 we\'ll be returning to the Digipolis offices. We\'ll have two talks lined up for you. Joeri Sebrechts will talk about a front-end framework his team opensourced. Tom Moors will introduce us in the wonderful world of DevOps.</div>',NULL,'<div>19:00 Doors<br>20:00 Talks</div>','<div>ACPaaS UI - why we made and open-sourced a front-end framework by Joeri Sebrechts<br><br>What if you had to deliver software to run many aspects of the daily life of more than half a million people? This is the particular challenge that Digipolis must solve for the city of Antwerp. It is that challenge that has led us to develop our own front-end framework called ACPaaS UI, built on top of Angular and React. This talk covers the why and how of this framework, the lessons learned along the way, and where we want to take it in the future.<br><br>Speaker: Joeri is a digital experience platform architect at Digipolis, working on elements of their ACPaaS city platform. Across his career as a software developer he has come into contact with many technologies and domains, from IOT to Big Data and most things in between. He considers himself an information addict and is always happy to learn new things.<br><br>Length: 45min</div>','<div>It\'s a DevOps world after all by Tom Moors<br><br>In 2009, the talk \"10+ deploys a day\" at Flickr ignited a whole new movement that got known as DevOps. Ten years later, we meet here just in time to make our New Year\'s resolutions. In this talk we\'ll revisit the foundations and dive into good, the bad (and even some ugly) practices to truly make in impact in 2019 - who wants to be a 10x developer if you can be a part of 100x team!<br><br>Speaker: Tom Moors is a 32 year old software engineer who spends his days improving the way how teams work together, mainly fueled by Atlassian tools. When the evening falls, he turns into a young father of 2 girls. Twitter: @tommoors<br><br>Length: 30min</div>','Our next meetup will be on 23/1 at the Digipolis offices. Talks will be on opensourcing front-end frameworks and a introduction to the world of DevOps. RSVP here: https://www.meetup.com/fullstackantwerp/events/vtkdppyzcbfc/',NULL,'2018-12-19 09:56:36','2018-12-19 13:39:50'),(3,3,'wpbpnqyzfbjb',NULL,'2019-03-06 19:00:00','<div>More info coming soon...</div>',NULL,'<div>19:00 Doors<br>20:00 Talks</div>',NULL,NULL,NULL,NULL,'2018-12-20 10:47:40','2018-12-20 10:47:40'),(4,2,'rqbpnqyzfbrb',NULL,'2018-12-20 12:43:41','<div>More info soon...</div>',NULL,'<div>19:00 Doors<br>20:00 Talks</div>','<div>ESNext: What\'s next for JavaScript? by Bram Van Damme<br><br>With the yearly ECMAScript releases (ES2015..ES2018) of a lot of things have changed in JavaScript-land. This talk takes a look at a few of the upcoming ECMAScript features, which (hopefully) will become part of the ECMAScript Language Specification in the near future.<br><br>Speaker: Bram Van Damme, nicknamed Bramus, is a 35 year old geezer who lives in Vinkt (Belgium) together with his son Finn and his daughter Tila.<br><br>With his company 3RDS he works as a freelance creative coder, tackling both the frontend and the backend. His current focus is on JavaScript, React and React Native. Before launching 3RDS, Bramus worked at several web agencies in various frontend en backend roles. For seven years he also was a Lecturer Web at a technical university in Belgium.<br><br>Length: 60min</div>',NULL,NULL,NULL,'2018-12-20 10:52:25','2018-12-20 13:43:41');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `meetups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meetups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meetup_com_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `meetups` WRITE;
/*!40000 ALTER TABLE `meetups` DISABLE KEYS */;
INSERT INTO `meetups` VALUES (1,'Full Stack Antwerp','full-stack-antwerp','fullstackantwerp','2018-12-11 15:56:21','2018-12-11 15:56:21'),(2,'Full Stack Ghent','full-stack-ghent','fullstackghent','2018-12-19 13:44:43','2018-12-19 13:44:43'),(3,'Full Stack Brussels','full-stack-brussels','fullstackbrussels','2018-12-20 10:43:05','2018-12-20 10:43:05');
/*!40000 ALTER TABLE `meetups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_01_01_000000_create_action_events_table',1),(4,'2018_12_08_115735_create_events_table',1),(5,'2018_12_08_115811_create_meetups_table',1),(6,'2018_12_08_151403_create_scheduled_tweets_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('freek@spatie.be','$2y$10$maurghRJ2vO640Ea6c3VnO7DqmvYPwDiCeFuIrkgWJbMPuoRKDdnu','2018-12-11 16:27:30');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scheduled_tweets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduled_tweets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `scheduled_to_be_sent_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tweet` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scheduled_tweets` WRITE;
/*!40000 ALTER TABLE `scheduled_tweets` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheduled_tweets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Freek','freek@spatie.be',NULL,'$2y$10$cODvrGMOTXdDf6KlvZzYfuyQJCUY7W/88ogrC9gKtKv8CPxO6hXcW',NULL,'2018-12-11 15:53:27','2018-12-11 15:55:37'),(2,'Dries','dries.vints@gmail.com',NULL,'$2y$10$ya1Fm3ENkczrJV5GwPTRjeRUESrfpnZGCWYukxrSOwdDs0jIGWimO','alLvym9UTxr614yAUUjlMwtp79fVM8xCmtbnakpWhS9ylcPDp1qJUESF8qMD','2018-12-17 10:02:22','2018-12-19 13:40:41'),(3,'Rias','rias@marbles.be',NULL,'$2y$10$4.DsdI59npAa90LTfr8P9.qchmpLwJdV.LXou7IHqn77IGZapfOPi','tO1XeyuKPJP4p1ls0xGqcPiGGaQSEoOUVPWI8OVRH0EEcFnaD9gmf55gS73z','2018-12-17 10:02:46','2018-12-17 10:16:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

